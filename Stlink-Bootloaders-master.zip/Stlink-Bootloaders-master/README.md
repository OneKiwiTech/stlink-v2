The 2 protected files were extracted from an ebay clone stlink and a nucleo pcb.
The 2 Unprotected files are the protected files with the call to the flash protection 
routine nop'd out at addresses 0x21B2 for V2.0 & 0x2A44 for V2.1


